import React, { useEffect } from 'react'
import { useNavigate } from 'react-router'
import { useLocation } from 'react-router-dom'
import { Result } from './models/IMessage'
import { read } from './Services'

function Detail() {

    const navigate =  useNavigate()
    const loc = useLocation()
    const item = loc.state as Result
    useEffect(() => {
        read( item.id! ).then( res => { })
    }, [])
    
    

  return (
    <>
        <div className='row'>
        <div className='col-sm-4'></div>
        <div className='col-sm-4'>
        <a role='button' onClick={(evt) => navigate('/home')} >
            <div className="card">
            <div className="card-body">
                <h5 className="card-title"> { item.subject }  </h5>
                <p className="card-text">  { item.content } </p>
                <p className="card-text">  { item.id } </p>
            </div>
            </div>
        </a>
        </div>
        <div className='col-sm-4'></div>
    </div>
    </>
  )
}

export default Detail