import axios from "axios";

const config = axios.create({
    baseURL: 'http://localhost:8080/message/'
})

export const save = ( subject: string, content: string  ) => {
    const sendItem = {
        subject: subject,
        content: content
    }
    return config.post('save', sendItem )
}

export const list = () => {
    return config.get("list")
}

export const read = ( id: number ) => {
    return config.get("read/"+id)
}