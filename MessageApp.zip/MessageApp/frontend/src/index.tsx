import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes,  Route } from 'react-router-dom'
import Detail from './Detail';
import Home from './Home';
import Welcome from './Welcome';

const routers = 
<BrowserRouter>
  <Routes>
    <Route path='/' element={ <Welcome></Welcome> } />
    <Route path='/home' element={ <Home></Home> } />
    <Route path='/detail' element={ <Detail></Detail> }></Route>
  </Routes>
</BrowserRouter>



const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(routers);