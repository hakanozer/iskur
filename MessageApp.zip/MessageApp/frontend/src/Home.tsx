import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { IMessage } from './models/IMessage'
import { list, save } from './Services'

function Home() {

    const navigate =  useNavigate()
    const [arr, setArr] = useState<IMessage>({})
    const [unread, setUnread] = useState(0)

    const [subject, setSubject] = useState('')
    const [content, setContent] = useState('')
    const fncSend = ( evt: React.FormEvent ) => {
        evt.preventDefault()
        save( subject, content ).then( res => {
            list().then( res => {
                setArr( res.data )
                const totalRead:IMessage = res.data
                const totalUnread = totalRead.result?.filter( item => item.read === false )
                setUnread( totalUnread!.length)
            } )
        })
    }

    useEffect(() => {
        list().then( res => {
            setArr( res.data )
            const totalRead:IMessage = res.data
            const totalUnread = totalRead.result?.filter( item => item.read === false )
            setUnread( totalUnread!.length)
        } )
    }, [])

    
  return (
    <>
    <div className='row'>
        <div className='col-sm-4'></div>
        <div className='col-sm-4'>
            <h2> Message Save </h2>
        <form onSubmit={fncSend}>
            <div className="mb-3">
                <label htmlFor="subject" className="form-label">Subject</label>
                <input onChange={(evt) => setSubject(evt.target.value) } className="form-control" id="subject" />
            </div>
            <div className="mb-3">
                <label htmlFor="content" className="form-label">Content</label>
                <input onChange={(evt) => setContent(evt.target.value) }  type="content" className="form-control" id="content" />
            </div>
            <button type="submit" className="btn btn-primary">Submit</button>
        </form>

    <h2>Message List</h2>
    <table className="table">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Subject</th>
        </tr>
    </thead>
    <tbody>
        { 
            arr.result?.map( (item, index) => 
                <tr key={index} role='button' onClick={(evt) => navigate('/detail', { state: item } ) } >
                    <th scope="row"> { item.id } </th>
                <td> { item.subject } </td>
            </tr>
            )
        }

  </tbody>
</table>
        </div>
        <div className='col-sm-4'></div>
    </div>



    </>
  )
}

export default Home