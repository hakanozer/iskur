import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { IMessage } from './models/IMessage'
import { list } from './Services'

function Welcome() {
    const navigate =  useNavigate()
    const [arr, setArr] = useState<IMessage>({})
    const [unread, setUnread] = useState(0)

  useEffect(() => {
    list().then( res => {
        setArr( res.data )
        const totalRead:IMessage = res.data
        const totalUnread = totalRead.result?.filter( item => item.read === false )
        setUnread( totalUnread!.length)
    } )
  }, [])
    

  return (
    <>
    <div className='row'>
        <div className='col-sm-4'></div>
        <div className='col-sm-4'>
        <a role='button' onClick={(evt) => navigate('/home')} >
            <div className="card">
            <div className="card-body">
                <h5 className="card-title">Hello Onur</h5>
                <p className="card-text">Total Message : { arr.result?.length }</p>
                <p className="card-text">Unread : { unread }</p>
            </div>
            </div>
        </a>
        </div>
        <div className='col-sm-4'></div>
    </div>

    </>
  )
}

export default Welcome