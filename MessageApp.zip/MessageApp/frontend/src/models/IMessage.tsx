export interface IMessage {
    status?: boolean;
    result?: Result[];
}

export interface Result {
    id?:      number;
    subject?: string;
    content?: string;
    read?:    boolean;
}
